---
layout: default
---

![FreedomBrowser Domain Index](./domain-index.png)

# Currently active domains
1. Main website: [freedombrowser.org](https://freedombrowser.org)
2. Secondary website: [freedombrowser.tk](https://freedombrowser.tk)
3. Mostly unlocked website: [freedombrowser.uk.to](https://freedombrowser.uk.to)
4. Disguised website: [classroom.google.uk.to](https://classroom.google.uk.to)
5. Development site: [beta.freedombrowser.stonklat.com](https://stonklat.com/freedombrowser)

## Other domains
1. Developer site: [freedombrowser.github.io](https://freedombrowser.github.io)
2. Domain Index: _you're here_
3. Backend domain: [stonklat.com](https://stonklat.com)
4. Minecraft domain: [mc.stonklat.com](http://mc.stonklat.com)