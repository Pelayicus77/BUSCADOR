<p align="center"><img src="https://raw.githubusercontent.com/freedombrowser/Infrared/main/src/public/ir.png" height="200"></p>

<h1 align="center">Infrared Static</h1>

Freedombrowser's new main proxy, it still uses ultraviolet but we have switched to a static based frontend because it is much faster. The frontend is a fork of [titaniumnetwork-dev/Ultraviolet-App](https://github.com/titaniumnetwork-dev/Ultraviolet-App/) but we have and will modify and optimise it to better suit the need of a Freedombrowser user


